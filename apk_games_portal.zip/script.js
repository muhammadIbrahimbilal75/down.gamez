// Games data
const games = {
  "Action Games": ["GTA San Andreas", "GTA Vice City", "Call of Duty Mobile", "PUBG Mobile", "Free Fire"],
  "Racing Games": ["Asphalt 9: Legends", "Need for Speed: No Limits", "Real Racing 3"],
  "Adventure Games": ["Minecraft PE", "Terraria", "The Walking Dead: Season One"],
  "RPG Games": ["Final Fantasy VII", "Chrono Trigger", "Eternium"],
  "Strategy Games": ["Clash of Clans", "XCOM 2 Collection", "Plague Inc."],
  "Sports Games": ["FIFA Mobile", "NBA 2K Mobile Basketball", "Madden NFL Mobile Football"]
};

// Function to generate game links
function generateGameLinks(category, gamesList) {
  const section = document.createElement("section");
  const heading = document.createElement("h2");
  heading.textContent = category;
  section.appendChild(heading);

  const list = document.createElement("ul");
  gamesList.forEach(game => {
    const listItem = document.createElement("li");
    const apkpureLink = document.createElement("a");
    apkpureLink.href = `https://apkpure.com/search?q=${encodeURIComponent(game)}`;
    apkpureLink.textContent = `${game} (APKPure)`;
    apkpureLink.target = "_blank";

    const apkmirrorLink = document.createElement("a");
    apkmirrorLink.href = `https://www.apkmirror.com/?s=${encodeURIComponent(game)}`;
    apkmirrorLink.textContent = `${game} (APKmirror)`;
    apkmirrorLink.target = "_blank";

    listItem.appendChild(apkpureLink);
    listItem.appendChild(document.createTextNode(" | "));
    listItem.appendChild(apkmirrorLink);
    list.appendChild(listItem);
  });

  section.appendChild(list);
  return section;
}

// Render all games
const gamesListSection = document.getElementById("games-list");
for (const [category, gamesList] of Object.entries(games)) {
  gamesListSection.appendChild(generateGameLinks(category, gamesList));
}